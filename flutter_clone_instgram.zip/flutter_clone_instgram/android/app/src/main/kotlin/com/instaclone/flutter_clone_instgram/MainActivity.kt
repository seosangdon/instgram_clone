package com.instaclone.flutter_clone_instgram

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
